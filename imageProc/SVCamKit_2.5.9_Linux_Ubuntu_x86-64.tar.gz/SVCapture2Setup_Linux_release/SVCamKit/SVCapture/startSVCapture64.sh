#!/bin/bash
export QT_QPA_PLATFORM_PLUGIN_PATH=./plugins/platforms
./SVCapture64

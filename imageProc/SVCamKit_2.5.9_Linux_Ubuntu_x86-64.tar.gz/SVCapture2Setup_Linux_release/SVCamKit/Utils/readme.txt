SVCamKit: GigE_IPConfig tool

NOTE: 
To use this tool, an elevated privilege is needed.

Usage:
sudo chmod +x GigE_IPConfig
sudo ./GigE_IPConfig
